Dhanraj Shetty Haldi cinematic website

Open index.html for the 8-slide automatic cinematic slideshow.
Open opening.html, royal-portrait.html, haldi-carnival.html, royal-haldi-stage.html, grand-welcome.html, love-and-petals.html, royal-groom.html or closing.html to inspect each sheet individually.

All pages share the same burgundy / ivory-gold styling and original image assets. Use the Previous / Next / All slides links to navigate.

GitHub Pages: upload all files and the assets folder to the repository root; Settings > Pages > Deploy from branch > main / root. The public site opens index.html.
